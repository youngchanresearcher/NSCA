set.seed(7)
x <- sort(runif(120))
y <- pmin(pmax(x + rnorm(120, 0, 0.12), 0), 1)
grid <- seq(min(x), max(x), length.out = 2001L)

test_that("each corner selects the matching running extreme", {
  upper_left <- NSCA:::.nsca_step_frontier(x, y, 1L, grid)
  lower_right <- NSCA:::.nsca_step_frontier(x, y, 4L, grid)
  expect_false(is.unsorted(upper_left))           # non-decreasing
  expect_false(is.unsorted(lower_right))          # non-decreasing
  expect_true(all(upper_left >= lower_right - 1e-9))
  expect_equal(upper_left[[length(grid)]], max(y))
  expect_equal(lower_right[[1L]], min(y))
})

test_that("the empty areas and the band decompose the scope", {
  # Exact envelopment frontiers cannot overlap, so the two empty zones plus the
  # admissible region must account for the whole scope. This is the identity
  # the package refuses to rely on for regression frontiers.
  for (direction in c("HH", "LH", "HL", "LL")) {
    yy <- if (direction %in% c("HH", "LL")) y else 1 - y
    corners <- nsca_corners(direction)
    nec <- NSCA:::.nsca_step_frontier(x, yy, corners$necessity_corner, grid)
    suf <- NSCA:::.nsca_step_frontier(x, yy, corners$sufficiency_corner, grid)
    bounds <- c(min(yy), max(yy))
    span <- diff(range(grid)) * diff(bounds)

    empty <- function(values, side) {
      NSCA:::.nsca_integrate(
        if (side == "upper") bounds[[2L]] - values else values - bounds[[1L]],
        grid
      )
    }
    d_nec <- empty(nec, corners$necessity_bound) / span
    d_suf <- empty(suf, corners$sufficiency_bound) / span
    band <- if (corners$necessity_bound == "upper") {
      NSCA:::.nsca_band(nec, suf, grid, bounds)
    } else {
      NSCA:::.nsca_band(suf, nec, grid, bounds)
    }
    expect_equal(d_nec + d_suf + band$area / span, 1, tolerance = 1e-6,
                 info = direction)
    expect_false(isTRUE(band$crossed), info = direction)
  }
})

test_that("crossing frontiers are reported rather than silently absorbed", {
  crossing_upper <- grid
  crossing_lower <- 1 - grid
  band <- NSCA:::.nsca_band(crossing_upper, crossing_lower, grid, c(0, 1))
  expect_true(band$crossed)
  expect_true(band$area > 0)          # only the positive part is counted
  expect_true(band$area < 0.5)
})

test_that("a deterministic relation leaves no band", {
  band <- NSCA:::.nsca_band(grid, grid, grid, c(0, 1))
  expect_equal(band$area, 0, tolerance = 1e-9)
})
