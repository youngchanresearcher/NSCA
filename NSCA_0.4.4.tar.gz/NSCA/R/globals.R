# Variables captured by ggplot2's data-masked aesthetics.
utils::globalVariables(c("side", "x", "y", "ymax", "ymin"))
